(function () {
  'use strict';

  /**
   * Service for taking screenshots.
   */
  function twxPictureService(tml3dRenderer) {
    return {
      restrict: 'E',
      link: function (scope, el) {
        // Add an element for flashing efect used when taking pictures.
        const flashEl = document.createElement('div');
        flashEl.classList.add('take-screenshot-flash', 'take-screenshot-flash-fade');
        document.querySelector('twx-dt-view').appendChild(flashEl);

        scope.$on('serviceInvoke', function (event, data) {
          const name = data.serviceName;
          if (scope.services[name]) {
            scope.services[name](data.params);
          }
        });

        scope.services = {
          /**
           * Takes screenshot of current view.
           */
          takePicture: function () {
            if (!tml3dRenderer.takeScreenshot) {
              console.error('takePicture: tml3dRenderer.takeScreenshot not available');
              return;
            }

            console.log('takePicture: tml3dRenderer.takeScreenshot available, calling...');
            const config = { withAugmentation: !scope.me.isAugmentationsHidden };
            let elements = [];
            if (scope.me.isAugmentationsHidden) {
              elements = twx.app.fn.hideAll3DWidgets();
            }
            tml3dRenderer.takeScreenshot(config, function success(data, params) {
              console.log('takePicture: tml3dRenderer.takeScreenshot succeeded', data, JSON.stringify(params));
              flash();
              scope.me.image = data;
              scope.$emit('pictureTaken', { data: data, params: params });
              twx.app.fn.unhideAll3DWidgets(elements);
              scope.$apply();
            }, function failure() {
              scope.me.image = null;
              twx.app.fn.unhideAll3DWidgets(elements);
              scope.$apply();
              console.error('takePicture: tml3dRenderer.takeScreenshot failed', JSON.stringify(arguments));
            });
          }
        };

        function flash() {
          // Class change triggers css transition.
          flashEl.classList.remove('take-screenshot-flash-fade');
          setTimeout(() => {
            flashEl.classList.add('take-screenshot-flash-fade');
          });
        }
      }
    };
  }

  angular.module('ngPictureService', ['vuforia-angular'])
    .directive('twxPictureService', [ 'tml3dRenderer', twxPictureService ]);
}());
