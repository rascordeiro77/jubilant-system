// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


$timeout(function() {

$scope.view.wdg['pinger_doorlock'].shader  =  "pinger;rings f 5;rate f 15;direction f -1;r f 0;g f 1;b f 0";
$scope.view.wdg['pinger_cashless'].shader  =  "pinger;rings f 5;rate f 15;direction f -1;r f 0;g f 1;b f 0";
$scope.view.wdg['pinger_scanner'].shader  =  "pinger;rings f 5;rate f 15;direction f -1;r f 0;g f 1;b f 0";
$scope.view.wdg['doorLockText'].visible = false;  

$scope.view.wdg['pinger_doorlock'].onclick = console.log("CLICK") 
},1000);

$scope.startBtn= function(){
  console.log("BUTTON PRESSED")

  $scope.view.wdg['instructionsBox']["visible"] = false
  $scope.view.wdg['button1']["visible"] = false
}

//module for clicking pinger --> displaying text bubble --> play sequence or close bubble options
var doorLock = 0;


$scope.doorLockPinger = function(){
  console.log("PINGER CLICK");
  
  if(doorLock == 0){
  openDoorLockText();
   
  }else{
    $scope.view.wdg['doorLockText'].visible = false; 
    doorLock = 0;
  }
  

}


openDoorLockText = function(){
 console.log("SHOW DOOR LOCK TEXT"); 
  $scope.view.wdg['doorLockText'].visible = true;
  doorLock = 1;
}


/*$scope.actionDL = function(){
 console.log("CLICKED BUBBLE DO SOMETHING");
  
  //$scope.view.wdg['model'].play()
}
*/



