(function(){
  window.twx = window.twx || {};

  var requires = ["ionic","twx.byoc","ngJustGage","common-html-widgets-ng","ngBarcodeScannerService","chartjs-ng"];
  var twxViewControllersModule = angular.module('twxViewControllers', requires);
  twxViewControllersModule.run(function($templateCache) {
    //Inject an ng-if for preview cases where the web-assembly module needs time to load & compile async.
    //Delays loading model-items until its ready and the model tags are processed.
    
      var viewHTML =  '<ion-view hasGridEvenRows="false" view-type="ar" twx-view="Home" view-title="Home" ctrl-name="Home_TwxViewController" can-swipe-back="false"><div class="overlay ng-hide" ng-show=""></div><ion-content scroll="false" ><twx-widget widget-id="view-1" original-widget="twx-view" widget-name="view-1"><twx-widget-property name="widgetName" datatype="string" value="view-1"></twx-widget-property><twx-widget-property name="viewtype" datatype="string" value="ar"></twx-widget-property><twx-widget-property name="class" datatype="string"></twx-widget-property><twx-widget-content><twx-container-content class="{{me.class}}"><twx-widget widget-id="3DContainer-1" original-widget="twx-dt-view" widget-name="3D Container"><twx-widget-service name="unlockCameraAndOrientation"></twx-widget-service><twx-widget-service name="lockCameraAndOrientation"></twx-widget-service><twx-widget-property name="widgetName" datatype="string" value="3D Container"></twx-widget-property><twx-widget-property name="far" datatype="number" value="200"></twx-widget-property><twx-widget-property name="near" datatype="number" value="0.01"></twx-widget-property><twx-widget-property name="dropshadow" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="enabletrackingevents" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="camera" datatype="json" value="{}"></twx-widget-property><twx-widget-property name="persistmap" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="src" datatype="string" value="TW-VuMark.xml"></twx-widget-property><twx-widget-property name="extendedtracking" datatype="boolean" value="true"></twx-widget-property><twx-widget-property name="visible" datatype="boolean" value="true"></twx-widget-property><twx-widget-content><twx-dt-view near="0.01" far="200" extendedtracking="true" persistmap="false" dropshadow="{{me.dropshadow}}">\n'+
'     <twx-dt-tracker id="tracker1" enabletrackingevents="false">\n'+
'        <twx-container-content>\n'+
'           <div class="targetGuide" ng-class="targetGuideClass" ng-hide="hideTargetGuide">\n'+
'               <div class="bracket-top-left"></div>\n'+
'               <div class="bracket-top-right"></div>\n'+
'               <div class="bracket-bottom-right"></div>\n'+
'               <div class="bracket-bottom-left"></div>\n'+
'               <div class="targetGuideText hint" ng-hide="hideTargetGuide">{{targetGuideHint}}</div>\n'+
'           </div>\n'+
'        <twx-widget widget-id="thingMark-1" original-widget="twx-dt-target" widget-name="thingMark-1"><twx-widget-property name="widgetName" datatype="string" value="thingMark-1"></twx-widget-property><twx-widget-property name="decal" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="stationary" datatype="boolean" value="true"></twx-widget-property><twx-widget-property name="trackingIndicator" datatype="boolean" value="true"></twx-widget-property><twx-widget-property name="istracked" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="placeholder_img" datatype="" value="/extensions/images/placeholder_thingmark.png"></twx-widget-property><twx-widget-property name="rz" datatype="number" value="-180"></twx-widget-property><twx-widget-property name="ry" datatype="number" value="-90"></twx-widget-property><twx-widget-property name="rx" datatype="number" value="90.00"></twx-widget-property><twx-widget-property name="z" datatype="number" value="0.0000"></twx-widget-property><twx-widget-property name="y" datatype="number" value="0.0000"></twx-widget-property><twx-widget-property name="x" datatype="number" value="0.0000"></twx-widget-property><twx-widget-property name="width" datatype="number" value="0.0254"></twx-widget-property><twx-widget-property name="markerId" datatype="string" value=""></twx-widget-property><twx-widget-content><twx-dt-target id="thingMark-1" src="{{&apos;vuforia-vumark:///vumark?id=&apos; + me.markerId}}" guide-src="app/resources/Default/thing_code_phantom.png" size="{{me.width}}" x="{{me.x}}" y="{{me.y}}" z="{{me.z}}" rx="{{me.rx}}" ry="{{me.ry}}" rz="{{me.rz}}" istracked="{{me.istracked}}" trackingindicator="{{me.trackingIndicator}}" stationary="{{me.stationary}}"><twx-dt-image id="thingMark-1-image" sx="{{me.width*4.51}}" sy="{{me.width*4.51}}" sz="{{me.width*4.51}}" x="{{me.x}}" y="{{me.y}}" z="{{me.z}}" rx="{{me.rx}}" ry="{{me.ry}}" rz="{{me.rz}}" hidden="{{!me.trackingIndicator}}" billboard="{{me.billboard}}" occlude="{{me.occlude}}" decal="{{me.decal}}" shader="recogniser;active f {{pulse}}" src="img/recognised.png?name=sampler0 img/recognised2.png?name=sampler1" trackingindicator="{{me.trackingIndicator}}" stationary="{{me.stationary}}"></twx-dt-image></twx-dt-target></twx-widget-content><twx-databind databind-id="db-1574796501806" source-type="data" source-name="vumark" source-item-type="value" source-item-name="vumark" binding-type="custom_field" from-expression="app.params[&apos;vumark&apos;]" to-property="markerId"></twx-databind></twx-widget><twx-widget widget-id="model" original-widget="twx-dt-model" widget-name="model"><twx-widget-service name="stop"></twx-widget-service><twx-widget-service name="rewind"></twx-widget-service><twx-widget-service name="reset"></twx-widget-service><twx-widget-service name="playAll"></twx-widget-service><twx-widget-service name="play"></twx-widget-service><twx-widget-service name="forward"></twx-widget-service><twx-widget-property name="widgetName" datatype="string" value="model"></twx-widget-property><twx-widget-property name="sequencePartIds" datatype="string"></twx-widget-property><twx-widget-property name="playing" datatype="boolean"></twx-widget-property><twx-widget-property name="stepDescription" datatype="string"></twx-widget-property><twx-widget-property name="stepName" datatype="string"></twx-widget-property><twx-widget-property name="currentStep" datatype="number"></twx-widget-property><twx-widget-property name="steps" datatype="number"></twx-widget-property><twx-widget-property name="showSequenceInCanvas" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="sequence" datatype="resource_url" value=""></twx-widget-property><twx-widget-property name="sequenceList" datatype="infotable"></twx-widget-property><twx-widget-property name="shader" datatype="string" value=""></twx-widget-property><twx-widget-property name="translucent" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="opacity" datatype="number" value="1"></twx-widget-property><twx-widget-property name="decal" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="occlude" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="forceHidden" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="visible" datatype="boolean" value="true"></twx-widget-property><twx-widget-property name="rz" datatype="number" value="-0.35"></twx-widget-property><twx-widget-property name="ry" datatype="number" value="0.00"></twx-widget-property><twx-widget-property name="rx" datatype="number" value="0.00"></twx-widget-property><twx-widget-property name="z" datatype="number" value="0.025394722819328308"></twx-widget-property><twx-widget-property name="y" datatype="number" value="0.0022778422571718693"></twx-widget-property><twx-widget-property name="x" datatype="number" value="-0.0071704089641571045"></twx-widget-property><twx-widget-property name="scale" datatype="string" value="1"></twx-widget-property><twx-widget-property name="src" datatype="resource_url" value="app/resources/Uploaded/gt28doorOpen.pvz"></twx-widget-property><twx-widget-content><twx-dt-model id="model" ng-src="{{me.src | trustUrl}}" src="app/resources/Uploaded/gt28doorOpen.pvz" sx="{{me.scale.split(&apos; &apos;)[0] || me.scale}}" sy="{{me.scale.split(&apos; &apos;)[1] || me.scale}}" sz="{{me.scale.split(&apos; &apos;)[2] || me.scale}}" x="{{me.x}}" y="{{me.y}}" z="{{me.z}}" rx="{{me.rx}}" ry="{{me.ry}}" rz="{{me.rz}}" hidden="{{!app.fn.isTrue(me.visible)}}" force-hidden="{{me.forceHidden}}" occlude="{{me.occlude}}" decal="{{me.decal}}" opacity="{{me.opacity}}" phantom="{{!me.translucent}}" shader="{{me.shader}}" sequencelist="{{me.sequenceList}}" sequence="{{me.sequence}}" showsequenceincanvas="{{me.showSequenceInCanvas}}" steps="{{me.steps}}" currentstep="{{me.currentStep}}" stepname="{{me.stepName}}" stepdescription="{{me.stepDescription}}" playing="{{me.playing}}" sequencepartids="{{me.sequencePartIds}}"><twx-container-content></twx-container-content></twx-dt-model></twx-widget-content></twx-widget><twx-widget widget-id="pinger_doorlock" original-widget="twx-dt-image" widget-name="pinger_doorlock"><twx-widget-event name="click" value="doorLockPinger()"></twx-widget-event><twx-widget-property name="widgetName" datatype="string" value="pinger_doorlock"></twx-widget-property><twx-widget-property name="placeholder_img" datatype="" value="/extensions/images/placeholder_img.svg"></twx-widget-property><twx-widget-property name="shader" datatype="string" value=""></twx-widget-property><twx-widget-property name="pivot" datatype="select" value="5"></twx-widget-property><twx-widget-property name="opacity" datatype="number" value="1"></twx-widget-property><twx-widget-property name="experimentalOneSided" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="decal" datatype="boolean" value="true"></twx-widget-property><twx-widget-property name="occlude" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="billboard" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="visible" datatype="boolean" value="true"></twx-widget-property><twx-widget-property name="rz" datatype="number" value="-0.32"></twx-widget-property><twx-widget-property name="ry" datatype="number" value="0.05"></twx-widget-property><twx-widget-property name="rx" datatype="number" value="0.70"></twx-widget-property><twx-widget-property name="z" datatype="number" value="0.6649"></twx-widget-property><twx-widget-property name="y" datatype="number" value="0.7121"></twx-widget-property><twx-widget-property name="x" datatype="number" value="0.7485"></twx-widget-property><twx-widget-property name="scale" datatype="string" value="0.4000"></twx-widget-property><twx-widget-property name="class" datatype="string"></twx-widget-property><twx-widget-property name="width" datatype="number" value=""></twx-widget-property><twx-widget-property name="height" datatype="number" value=""></twx-widget-property><twx-widget-property name="src" datatype="resource_url" value="app/resources/Uploaded/pinger.png"></twx-widget-property><twx-widget-content><twx-dt-image id="pinger_doorlock" ng-src="{{me.src | trustUrl}}" src="app/resources/Uploaded/pinger.png" height="{{me.height}}" width="{{me.width}}" class="basic-3d-state-formatting {{me.class}}" sx="{{me.scale.split(&apos; &apos;)[0] || me.scale}}" sy="{{me.scale.split(&apos; &apos;)[1] || me.scale}}" sz="{{me.scale.split(&apos; &apos;)[2] || me.scale}}" x="{{me.x}}" y="{{me.y}}" z="{{me.z}}" rx="{{me.rx}}" ry="{{me.ry}}" rz="{{me.rz}}" hidden="{{!app.fn.isTrue(me.visible)}}" billboard="{{me.billboard}}" occlude="{{me.occlude}}" decal="{{me.decal}}" experimental-one-sided="{{me.experimentalOneSided}}" opacity="{{me.opacity}}" pivot="{{me.pivot}}" shader="{{me.shader}}" interactable-hint="true"></twx-dt-image></twx-widget-content></twx-widget><twx-widget widget-id="doorLockText" original-widget="twx-dt-image" widget-name="doorLockText"><twx-widget-property name="widgetName" datatype="string" value="doorLockText"></twx-widget-property><twx-widget-property name="placeholder_img" datatype="" value="/extensions/images/placeholder_img.svg"></twx-widget-property><twx-widget-property name="shader" datatype="string" value=""></twx-widget-property><twx-widget-property name="pivot" datatype="select" value="5"></twx-widget-property><twx-widget-property name="opacity" datatype="number" value="1"></twx-widget-property><twx-widget-property name="experimentalOneSided" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="decal" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="occlude" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="billboard" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="visible" datatype="boolean" value="true"></twx-widget-property><twx-widget-property name="rz" datatype="number" value="0.00"></twx-widget-property><twx-widget-property name="ry" datatype="number" value="0.00"></twx-widget-property><twx-widget-property name="rx" datatype="number" value="5.01"></twx-widget-property><twx-widget-property name="z" datatype="number" value="0.7460"></twx-widget-property><twx-widget-property name="y" datatype="number" value="0.9404"></twx-widget-property><twx-widget-property name="x" datatype="number" value="1.2828"></twx-widget-property><twx-widget-property name="scale" datatype="string" value="3.0000"></twx-widget-property><twx-widget-property name="class" datatype="string"></twx-widget-property><twx-widget-property name="width" datatype="number" value=""></twx-widget-property><twx-widget-property name="height" datatype="number" value=""></twx-widget-property><twx-widget-property name="src" datatype="resource_url" value="app/resources/Uploaded/pic1.png"></twx-widget-property><twx-widget-content><twx-dt-image id="doorLockText" ng-src="{{me.src | trustUrl}}" src="app/resources/Uploaded/pic1.png" height="{{me.height}}" width="{{me.width}}" class="basic-3d-state-formatting {{me.class}}" sx="{{me.scale.split(&apos; &apos;)[0] || me.scale}}" sy="{{me.scale.split(&apos; &apos;)[1] || me.scale}}" sz="{{me.scale.split(&apos; &apos;)[2] || me.scale}}" x="{{me.x}}" y="{{me.y}}" z="{{me.z}}" rx="{{me.rx}}" ry="{{me.ry}}" rz="{{me.rz}}" hidden="{{!app.fn.isTrue(me.visible)}}" billboard="{{me.billboard}}" occlude="{{me.occlude}}" decal="{{me.decal}}" experimental-one-sided="{{me.experimentalOneSided}}" opacity="{{me.opacity}}" pivot="{{me.pivot}}" shader="{{me.shader}}" interactable-hint="true"></twx-dt-image></twx-widget-content><twx-eventbind eventbind-id="eb-1586805006872" source-type="widget" source-label="3D Image" source-name="doorLockText" source-event="click" handler-type="ui" handler-name="model" handler-service="playAll" handler-path="app.view[&quot;Home&quot;].wdg[&quot;model&quot;].svc.playAll"></twx-eventbind></twx-widget><twx-widget widget-id="tmlText-1" original-widget="twx-tml-text" widget-name="tmlText-1"><twx-widget-property name="widgetName" datatype="string" value="tmlText-1"></twx-widget-property><twx-widget-content><script name="pinger" type="x-shader/x-vertex">\n'+
' attribute vec4 vertexPosition;\n'+
' attribute vec2 vertexTexCoord;\n'+
'\n'+
' varying vec2 texcoord;\n'+
'\n'+
' uniform mat4 modelViewProjectionMatrix;\n'+
' void main() {\n'+
'   gl_Position=vec4(modelViewProjectionMatrix * vertexPosition);\n'+
'   texcoord = vertexTexCoord - 0.5;\n'+
' }\n'+
'</script>\n'+
'\n'+
'<script name="pinger" type="x-shader/x-fragment">\n'+
' precision mediump float;\n'+
' const float PI=3.1415926;\n'+
' varying vec2 texcoord;\n'+
'\n'+
' uniform float rings;\n'+
' uniform float fade;\n'+
' uniform float rate;\n'+
' uniform float direction;\n'+
' uniform float r;\n'+
' uniform float g;\n'+
' uniform float b;\n'+
' uniform float tick;\n'+
'\n'+
' uniform vec4 surfaceColor;\n'+
' void main() {\n'+
'   float viz = 1. - fade;\n'+
'   float wrap = 2. * PI;\n'+
'   float speed = (direction < 0.) ? 1.+rate : -1.-rate;   // note there is a default speed (1) and the rate then adjusts it\n'+
'   float o= speed * mod(tick,wrap);\n'+
'   float l=length(texcoord)*PI;\n'+
'   float freq = max(rings * 2.,1.);\n'+
'   float fr=o + (l * freq);\n'+
'   float a1=sin(fr);\n'+
'   float a2=clamp(cos(l),0.,1.); // edge fade is a cosine\n'+
'   float a = viz * a1 * a2;\n'+
'\n'+
'   vec3 c = vec3(r,g,b);\n'+
'   if (length(c) == 0.) c=vec3(0.,1.,0.);  //thingview bug - should be surfaceColor.xyz; //\n'+
'   if (a<0.) discard;\n'+
'   else gl_FragColor=vec4(c,a);\n'+
' }\n'+
'</script></twx-widget-content></twx-widget><twx-widget widget-id="pinger_scanner" original-widget="twx-dt-image" widget-name="pinger_scanner"><twx-widget-event name="click" value="scannerPinger()"></twx-widget-event><twx-widget-property name="widgetName" datatype="string" value="pinger_scanner"></twx-widget-property><twx-widget-property name="placeholder_img" datatype="" value="/extensions/images/placeholder_img.svg"></twx-widget-property><twx-widget-property name="shader" datatype="string" value=""></twx-widget-property><twx-widget-property name="pivot" datatype="select" value="5"></twx-widget-property><twx-widget-property name="opacity" datatype="number" value="1"></twx-widget-property><twx-widget-property name="experimentalOneSided" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="decal" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="occlude" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="billboard" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="visible" datatype="boolean" value="true"></twx-widget-property><twx-widget-property name="rz" datatype="number" value="0.00"></twx-widget-property><twx-widget-property name="ry" datatype="number" value="0.00"></twx-widget-property><twx-widget-property name="rx" datatype="number" value="1.27"></twx-widget-property><twx-widget-property name="z" datatype="number" value="0.6966"></twx-widget-property><twx-widget-property name="y" datatype="number" value="1.3292"></twx-widget-property><twx-widget-property name="x" datatype="number" value="0.7867"></twx-widget-property><twx-widget-property name="scale" datatype="string" value="0.4000"></twx-widget-property><twx-widget-property name="class" datatype="string"></twx-widget-property><twx-widget-property name="width" datatype="number" value=""></twx-widget-property><twx-widget-property name="height" datatype="number" value=""></twx-widget-property><twx-widget-property name="src" datatype="resource_url" value="app/resources/Uploaded/pinger.png"></twx-widget-property><twx-widget-content><twx-dt-image id="pinger_scanner" ng-src="{{me.src | trustUrl}}" src="app/resources/Uploaded/pinger.png" height="{{me.height}}" width="{{me.width}}" class="basic-3d-state-formatting {{me.class}}" sx="{{me.scale.split(&apos; &apos;)[0] || me.scale}}" sy="{{me.scale.split(&apos; &apos;)[1] || me.scale}}" sz="{{me.scale.split(&apos; &apos;)[2] || me.scale}}" x="{{me.x}}" y="{{me.y}}" z="{{me.z}}" rx="{{me.rx}}" ry="{{me.ry}}" rz="{{me.rz}}" hidden="{{!app.fn.isTrue(me.visible)}}" billboard="{{me.billboard}}" occlude="{{me.occlude}}" decal="{{me.decal}}" experimental-one-sided="{{me.experimentalOneSided}}" opacity="{{me.opacity}}" pivot="{{me.pivot}}" shader="{{me.shader}}" interactable-hint="true"></twx-dt-image></twx-widget-content></twx-widget><twx-widget widget-id="pinger_cashless" original-widget="twx-dt-image" widget-name="pinger_cashless"><twx-widget-event name="click" value="cashlessPinger()"></twx-widget-event><twx-widget-property name="widgetName" datatype="string" value="pinger_cashless"></twx-widget-property><twx-widget-property name="placeholder_img" datatype="" value="/extensions/images/placeholder_img.svg"></twx-widget-property><twx-widget-property name="shader" datatype="string" value=""></twx-widget-property><twx-widget-property name="pivot" datatype="select" value="5"></twx-widget-property><twx-widget-property name="opacity" datatype="number" value="1"></twx-widget-property><twx-widget-property name="experimentalOneSided" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="decal" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="occlude" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="billboard" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="visible" datatype="boolean" value="true"></twx-widget-property><twx-widget-property name="rz" datatype="number" value="-4.63"></twx-widget-property><twx-widget-property name="ry" datatype="number" value="-10.90"></twx-widget-property><twx-widget-property name="rx" datatype="number" value="3.40"></twx-widget-property><twx-widget-property name="z" datatype="number" value="0.6789"></twx-widget-property><twx-widget-property name="y" datatype="number" value="1.0514"></twx-widget-property><twx-widget-property name="x" datatype="number" value="0.7331"></twx-widget-property><twx-widget-property name="scale" datatype="string" value="0.4000"></twx-widget-property><twx-widget-property name="class" datatype="string"></twx-widget-property><twx-widget-property name="width" datatype="number" value=""></twx-widget-property><twx-widget-property name="height" datatype="number" value=""></twx-widget-property><twx-widget-property name="src" datatype="resource_url" value="app/resources/Uploaded/pinger.png"></twx-widget-property><twx-widget-content><twx-dt-image id="pinger_cashless" ng-src="{{me.src | trustUrl}}" src="app/resources/Uploaded/pinger.png" height="{{me.height}}" width="{{me.width}}" class="basic-3d-state-formatting {{me.class}}" sx="{{me.scale.split(&apos; &apos;)[0] || me.scale}}" sy="{{me.scale.split(&apos; &apos;)[1] || me.scale}}" sz="{{me.scale.split(&apos; &apos;)[2] || me.scale}}" x="{{me.x}}" y="{{me.y}}" z="{{me.z}}" rx="{{me.rx}}" ry="{{me.ry}}" rz="{{me.rz}}" hidden="{{!app.fn.isTrue(me.visible)}}" billboard="{{me.billboard}}" occlude="{{me.occlude}}" decal="{{me.decal}}" experimental-one-sided="{{me.experimentalOneSided}}" opacity="{{me.opacity}}" pivot="{{me.pivot}}" shader="{{me.shader}}" interactable-hint="true"></twx-dt-image></twx-widget-content></twx-widget></twx-container-content>\n'+
'     </twx-dt-tracker>\n'+
'</twx-dt-view></twx-widget-content></twx-widget><twx-widget widget-id="2DOverlay-1" original-widget="twx-overlay" widget-name="2D Overlay"><twx-widget-property name="widgetName" datatype="string" value="2D Overlay"></twx-widget-property><twx-widget-property name="class" datatype="string"></twx-widget-property><twx-widget-property name="visible" datatype="boolean" value="true"></twx-widget-property><twx-widget-content><div class="twx-2d-overlay {{me.class}}" ng-show="app.fn.isTrue(me.visible)"><twx-container-content><div class="panel undefined top" style=" "></div><div class="panel body undefined"><div class="panel undefined left" style=" flex: 0 0 50%"><twx-widget widget-id="instructionsBox" original-widget="twx-image2" widget-name="instructionsBox"><twx-widget-event name="click" value="instructionsBox()"></twx-widget-event><twx-widget-property name="widgetName" datatype="string" value="instructionsBox"></twx-widget-property><twx-widget-property name="padding" datatype="string" value=""></twx-widget-property><twx-widget-property name="visible" datatype="boolean" value="true"></twx-widget-property><twx-widget-property name="imageAlign" datatype="string" value="flex-start"></twx-widget-property><twx-widget-property name="height" datatype="string" value=""></twx-widget-property><twx-widget-property name="width" datatype="string" value=""></twx-widget-property><twx-widget-property name="backgroundcolor" datatype="string"></twx-widget-property><twx-widget-property name="imgsrc" datatype="resource_url" value="app/resources/Uploaded/initView_sm.png"></twx-widget-property><twx-widget-property name="class" datatype="string" value="instructionsView"></twx-widget-property><twx-widget-content><div class="imgAlignContainer" style="justify-content: flex-start;"><img class="{{me.class}}" ng-show="app.fn.isTrue(me.visible)" style="background-color: {{me.backgroundcolor}}; width: {{me.width}}; height: {{me.height}};  padding: {{me.padding}}" ng-src="{{me.imgsrc}}" twx-native-events=""></div></twx-widget-content></twx-widget></div><div class="panel undefined center" style=" "></div></div><div class="panel undefined bottom" style=" "><twx-widget widget-id="button1" original-widget="twx-button" widget-name="button1"><twx-widget-event name="click" value="startBtn()"></twx-widget-event><twx-widget-property name="widgetName" datatype="string" value="button1"></twx-widget-property><twx-widget-property name="margin" datatype="string"></twx-widget-property><twx-widget-property name="disabled" datatype="boolean" value="false"></twx-widget-property><twx-widget-property name="visible" datatype="boolean" value="true"></twx-widget-property><twx-widget-property name="class" datatype="string"></twx-widget-property><twx-widget-property name="text" datatype="string" value="Start"></twx-widget-property><twx-widget-content><button style="" ng-show="app.fn.isTrue(me.visible)" ng-disabled="app.fn.isTrue(me.disabled)" class="button {{me.class}}" twx-native-events="">{{me.text}}</button></twx-widget-content></twx-widget></div></twx-container-content></div></twx-widget-content></twx-widget></twx-container-content></twx-widget-content><twx-fragment-parameters></twx-fragment-parameters><twx-view-data></twx-view-data></twx-widget></ion-content></ion-view>\n';
      if (twx.app.isPreview() && viewHTML.indexOf('view-type="ar"') > 0) {
        viewHTML = viewHTML.replace(/<twx-dt-modelitem /ig, '<twx-dt-modelitem ng-if="$root.thingViewReady !== false" ');
      }
      $templateCache.put('app/components/Home.html', viewHTML);
    

    
  });

  

  twxViewControllersModule.controller('Home_TwxViewController',
      function ($scope, $element, $attrs, $timeout, $interval, $http, $ionicPopup, $ionicPopover, $stateParams, $location, $rootScope, tml3dRenderer, $injector, $sce) {
    $scope.app = twx.appScope;
    $scope.device = twx.device;
    $scope.view = {
        mdl: {
            custom: {}
        },
        wdg: {},
        fn: {},
        evt: {},
        prm: {},
        view: {}
    };

    var myWidgets = '';
    var activeWidgetEvents = {};
    var customWidgetEventListeners = [];

    if( $attrs['twxView'] !== undefined && $attrs['twxView'].length > 0 ) {
        $scope.app.view = $scope.app.view || {};
        $scope.app.view[$attrs['twxView']] = $scope.view;
    }

    this.setProperty = function(widgetProperty,value) {
        $scope.view.wdg[$attrs.widgetId][widgetProperty] = value;

    };

    this.addWidget = function(widgetScope,widgetElem,widgetAttrs) {
        var widgetId = widgetAttrs['widgetId'] || widgetAttrs['model'];
        var x = $scope;
        $scope.view.wdg = $scope.view.wdg || {};
        $scope.view.wdg[widgetId] = widgetScope[widgetId];
        myWidgets += '|' + widgetId;
        widgetScope['_widgetId'] = widgetId;
        //console.log('twxView --- adding widget "' + widgetId + '" to view - total widgets: ' + myWidgets);
    };

    $scope.getWidgetScope = function(widgetId){
      return $scope.view.wdg[widgetId];
    };

    $scope.getWidgetProp = function (widgetId, prop) {
      var propVal;
      if ($scope.view.wdg[widgetId] && $scope.view.wdg[widgetId][prop]) {
        propVal = $scope.view.wdg[widgetId][prop];
      }
      return propVal;
    };

    $scope.setWidgetProp = function (widgetId, prop, val) {
      if ($scope.view.wdg[widgetId]) {
        $scope.view.wdg[widgetId][prop] = val;
      }
    };

    $scope.addWidgetEventListener = function (widgetId, widgetEvent, callback) {
      customWidgetEventListeners.push({
        widgetId: widgetId,
        widgetEvent: widgetEvent,
        callback: callback
      });
      if (!activeWidgetEvents[widgetEvent]) {
        activeWidgetEvents[widgetEvent] = true;
        $scope.$on(widgetEvent, function (event, args) {
          _.each(customWidgetEventListeners, function (listenerInfo) {
            if (listenerInfo.widgetId == event.targetScope.widgetId && listenerInfo.widgetEvent == event.name) {
              listenerInfo.callback();
            }
          });
        });
      }
    };

    $scope.pulse = 1.0;

    $scope.tracerWidth = 0.0;
    $scope.tracerHeight = 0.0;
    $scope.tracerDimensions = { minX: 0, maxX: 1, minY: 0, maxY: 1 };
    $scope.loadingPromise = null;
    $scope.modelLoaded = $element.find('twx-dt-model').length === 0;
    var modelCount = $element.find('twx-dt-model').length;
    var modelLoadedCount = 0;
    var targets = $element.find('twx-dt-target');

    // hide the target guide initially until the actual image to use is known.
    $scope.hideTargetGuide = true;

    function setImageTrackerTracerDimensions(src) {
      let image = new Image();
      image.onload = () => {
        $scope.tracerWidth = image.width;
        $scope.tracerHeight = image.height;
        $scope.$apply();
      };

      image.src = src;
    }

    var setGuideImageData = function() {
      if (targets[0]) { // assume one target only
        var src = targets[0].getAttribute("src");

        if (src.startsWith("vuforia-vumark://")) {
          $scope.hideTargetGuide = false;
          $scope.targetGuideClass = "thingmark";
          $scope.targetGuideHint = "Point camera at ThingMark";
        } else if (src.startsWith('vuforia-image://')) {
          $scope.hideTargetGuide = false;
          $scope.targetGuideClass = "imageTarget";
          $scope.targetGuideHint = 'Point camera at image';
          setImageTrackerTracerDimensions(targets[0].getAttribute("guide-src"));
        } else if (!src.startsWith("spatial://")) {
          $scope.hideTargetGuide = false;
          var targetGuideDiv = $element[0].querySelector("div.targetGuide");
          var guideSrc = targets[0].getAttribute("guide-src");
          if (targetGuideDiv && guideSrc) {
            $scope.targetGuideClass = "imagemark";
            targetGuideDiv.style.backgroundImage = "url('" + guideSrc + "')";
          }
        }
      }
    };

    $scope.$applyAsync(function() {
      // This has to be invoked asynchronously now to give angular time to digest and interpolate the value of
      // guide-src="{{ ... }}" to the real value.
      setGuideImageData();
    });

    $scope.$on('trackingacquired', function (evt, arg) {
      tml3dRenderer.getTracked(function(trackedObjects) {
        $scope.startLoadingIndicatorIfNeeded(trackedObjects);
        $scope.applyTargetGuideIfNeeded(trackedObjects);
      });
    });

    $scope.$on('trackinglost', function (evt, arg) {
      tml3dRenderer.getTracked(function(trackedObjects) {
        $scope.applyTargetGuideIfNeeded(trackedObjects);
      });
    });

    $scope.$on('modelLoaded', function (evt, arg) {
      modelLoadedCount++;
      $scope.modelLoaded = true;

      tml3dRenderer.getTracked(function(trackedObjects) {
        $scope.applyTargetGuideIfNeeded(trackedObjects);
      });
    });

    // starts the 'spinner' animation around the thing code while the model is loading
    $scope.startLoadingIndicatorIfNeeded = function (trackedObjects) {
      if (!twx.app.fn.isCompatibleObjectsTracked(trackedObjects, targets)) {
        return;
      }

      // Start animation if this is first successful call to startLoadingIndicatorIfNeeded.
      var spinnerInterval = 0.03;
      if ($scope.pulse === 1.0 && $scope.loadingPromise === null) {
        $scope.loadingPromise = $interval(function () {
          // stop the animation after it makes one complete loop around
          if($scope.pulse <= 0) {
            // stop the animation
            $interval.cancel($scope.loadingPromise);
            $scope.loadingPromise = null;
            $scope.pulse = 0;
          }
          $scope.pulse -= spinnerInterval;
        }, 100);
      }
    };

    /**
     * @param trackedObjects [Elements]
     */
    $scope.applyTargetGuideIfNeeded = function(trackedObjects) {
      var hideTargetGuide = twx.app.fn.computeHideTargetGuide(trackedObjects, targets, modelLoadedCount, modelCount);

      $scope.$apply(function () {
        $scope.hideTargetGuide = hideTargetGuide;
      });
    };

    (function($scope, $element, $attrs, $timeout){

      // $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


$timeout(function() {

$scope.view.wdg['pinger_doorlock'].shader  =  "pinger;rings f 5;rate f 15;direction f -1;r f 0;g f 1;b f 0";
$scope.view.wdg['pinger_cashless'].shader  =  "pinger;rings f 5;rate f 15;direction f -1;r f 0;g f 1;b f 0";
$scope.view.wdg['pinger_scanner'].shader  =  "pinger;rings f 5;rate f 15;direction f -1;r f 0;g f 1;b f 0";
$scope.view.wdg['doorLockText'].visible = false;  

$scope.view.wdg['pinger_doorlock'].onclick = console.log("CLICK") 
},1000);

$scope.startBtn= function(){
  console.log("BUTTON PRESSED")

  $scope.view.wdg['instructionsBox']["visible"] = false
  $scope.view.wdg['button1']["visible"] = false
}

//module for clicking pinger --> displaying text bubble --> play sequence or close bubble options
var doorLock = 0;


$scope.doorLockPinger = function(){
  console.log("PINGER CLICK");
  
  if(doorLock == 0){
  openDoorLockText();
   
  }else{
    $scope.view.wdg['doorLockText'].visible = false; 
    doorLock = 0;
  }
  

}


openDoorLockText = function(){
 console.log("SHOW DOOR LOCK TEXT"); 
  $scope.view.wdg['doorLockText'].visible = true;
  doorLock = 1;
}


/*$scope.actionDL = function(){
 console.log("CLICKED BUBBLE DO SOMETHING");
  
  //$scope.view.wdg['model'].play()
}
*/





    }($scope, $element, $attrs, $timeout))

  });

  

  var moduleDependencies = ['ionic', 'ngCordova', 'vuforia-angular', 'com.thingworx.services', 'twxRuntime'];
  var app = angular.module('app', moduleDependencies);
    twx = twx || {};
    twx.appXXX = app;

  app.config(function(DataConnectorConfigProvider, $ionicConfigProvider) {
    //Configured TWX server
    app.twxRoot = "/Thingworx";

    // Get this from application config later
    DataConnectorConfigProvider.addDataProvider({
        name: 'ThingworxConnector',
        urlRoot: app.twxRoot
    });

    $ionicConfigProvider.views.swipeBackEnabled(false);
  });

  // filter to allow remote resources (images, models, etc.) to be loaded
  app.filter('trustUrl', function($sce) {
      return function(url) {
          return $sce.trustAsResourceUrl(url);
      };
  });

  app.controller('AppCtrl', function ($scope, $rootScope, $state, $stateParams, $ionicModal, $location, $http, $injector, $templateCache) {
      var appScope = this;
      twx.appScope = this;
      var locationParams = {};
      // replace any occurrences of unreplaced URL params (i.e. {{foo:bar}}) with an empty string - DT-18867
      for(var entry of (new URLSearchParams(location.search.replace(/{{[a-zA-Z]*:[a-zA-Z]*}}/g, ''))).entries()) {
        locationParams[entry[0]] = entry[1];
      }
      twx.app.params = angular.extend(twx.app.params, $stateParams, locationParams);
      $scope.app.params = angular.extend({}, twx.app.params);
      appScope.params = twx.app.params;
      appScope.fn = twx.app.fn;
      appScope.mdl = twx.app.mdl;
      appScope.evt = twx.app.evt;

      twx.device.mdl['CurrentDevice'] = {
            svc: {
              'getCameraPictureURL': {}
            }
          };

      appScope.camera = {};
      appScope.camera.lastPictureData = "";
      appScope.camera.getPictureData = function(){
        var options = {
          destinationType: Camera.DestinationType.DATA_URL,
          sourceType: Camera.PictureSourceType.CAMERA
        };
        var $cordovaCamera = $injector.get('$cordovaCamera');
        $cordovaCamera.getPicture(options).then(function (imageData) {
          appScope.camera.lastPictureData = imageData;
        }, function (err) {
          console.error('Error getting camera.', err);
        });
      };

      appScope.camera.getPictureURL = function(){
        var options = {
          destinationType: Camera.DestinationType.FILE_URI,
          sourceType: Camera.PictureSourceType.CAMERA
        };
        var $cordovaCamera = $injector.get('$cordovaCamera');
        $cordovaCamera.getPicture(options).then(function (imageURI) {
          appScope.camera.lastPictureURL = imageURI;
          twx.device.mdl['CurrentDevice'].svc['getCameraPictureURL'].data = imageURI;
        }, function (err) {
          console.error('Error getting camera picture.', err);
        });
      };

      $scope.$on('device.mdl.CurrentDevice.svc.getCameraPictureURL', function () {
            appScope.camera.getPictureURL();
        });

      $scope.$on('app-fn-navigate',function(e,data) {
        twx.app.fn.navigate(data['viewname']);
      });

      if($rootScope.enableVoiceCommands && twx.app.isPreview()) {
        $rootScope.$on('$ionicView.afterEnter', function(event, toState, toParams, fromState, fromParams) {
          // get the app events each time the view changes to ensure we're displaying the "triggerable" app events for the current view
          $scope.appEvents = twx.app.getAppEventsWithHandlers();
        });
       }

      $scope.showModal = function(view){

        var modalContents = '';
        var modalUrl = 'app/components/' + view + '.html';
        $http.get(modalUrl).then(function(response) {
          modalContents = response.data;
          var modalTransformedContents = modalContents.replace('ion-view','ion-modal-view');
          $scope.modal = $ionicModal.fromTemplate(modalTransformedContents, {
            scope: $scope,
            animation: 'slide-in-up'
          });
          $scope.modal.show();
          $scope.$broadcast('show-modal');
        });

      };

      $scope.hideModal = function(){
        $scope.modal.hide();
        $scope.modal.remove();
      };

      $scope.$on('app-fn-show-modal',function(e,data) {
        // DT-18461 modalIsActive helps us to add particular listener in twxWidget controller (in runtime)
        $scope.modalIsActive = true;
        $scope.showModal(data['viewname']);
      });

      $scope.$on('app-fn-hide-modal',function(e,data) {
        delete $scope.modalIsActive;
        $scope.hideModal();
      });

      appScope.acceleration = {};
      appScope.location = {};
      appScope.location.getCurrentLocation = function(){
        var posOptions = {timeout: 10000, enableHighAccuracy: false};
        var $cordovaGeolocation = $injector.get('$cordovaGeolocation');
        $cordovaGeolocation
          .getCurrentPosition(posOptions)
          .then(function (position) {
            var lat  = position.coords.latitude;
            var long = position.coords.longitude;
            appScope.location.lastLocation = { latitude: lat, longitude: long };
          }, function(err) {
            console.error("Error getting current position", err);
          });
      };
      appScope.location.lastLocation = {
        latitude: 40.056545,
        longitude: -99.672037
      };

      if($rootScope.enableVoiceCommands) {
        // add the speech service to the app scope when there are voice alias'd app events
        appScope.speech = $injector.get('appSpeechService');
        if(twx.app.isPreview()) {
            // in preview for eyewear projects, we'll wrap the calls to app.speech.synthesizeSpeech so we can display the text in the snackbar
            appScope.speech.synthesizeSpeech = _.wrap(appScope.speech.synthesizeSpeech, function(func, info) {
              twx.app.fn.addSnackbarMessage(info.text, 'voice-response');
              return func(info);
            });
        }
      }

      twx.device.camera = appScope.camera;
      twx.device.location = appScope.location;
      twx.device.acceleration = appScope.acceleration;
      appScope.listCanSwipe = true;
    });

  app.controller('AppsMenuCtrl', function ($scope, $timeout, $http, $ionicSideMenuDelegate, $location, $ionicHistory) {
      $scope.isCordovaApp = window.cordova === undefined ? false : true;
      if( !($scope.isCordovaApp) ) {
        $scope.hasBackView = function () {
           return ($ionicHistory.backView() != null);
        };
      }
      else {
        //DT-12925: Disable swipe gesture to show the menu when the spatial target is in view
        $scope.$on('$ionicView.afterEnter', function() {
          $timeout(function() {
            $ionicSideMenuDelegate.canDragContent(document.querySelectorAll('[original-widget="twx-dt-target-spatial"]').length === 0);
          }, 10); //Just after other listeners still removing the old view widgets
        });
      }

      $scope.toggleLeftMenu = function () {
        $ionicSideMenuDelegate.toggleLeft();
      };

      $scope.navigateFromLeftMenu = function (path) {
        $location.path(path);
        $ionicSideMenuDelegate.toggleLeft();
      };

      $scope.$watch(function(){
          return $ionicSideMenuDelegate.getOpenRatio();
      }, function(newValue, oldValue) {
          $scope.hideLeftMenu = !$ionicSideMenuDelegate.isOpenLeft();
      });
    });

  app.controller('BaseCtrl', function ($scope, $parse, $location, $state, $ionicPopup, $timeout, $injector) {
    $scope['twInvokeAction'] = function(name){
      if (this['twActions'] && this['twActions'][name]){
        var action = this['twActions'][name];
        var fn = $parse(action.do, /* interceptorFn */ null, /* expensiveChecks */ true);
        fn(action.scope);
      } else {
        console.log('Action "' + name + '" not found');
      }
    };

    $scope._setCurrentAndNavigate = function(items, item, target){
      items.Current = item;
      $scope.navigate(target);
    };

    $scope.showConfirmPopup = function (title, subtitle, confirmEventId, confirmView) {
      var confirmPopup = $ionicPopup.confirm({
        title: title,
        template: subtitle
      });
      confirmPopup.then(function (res) {
        if (res) {
          $scope.$emit(confirmEventId);
          if (confirmView !== '') {
            $scope.navigateOnTimeout(confirmView);
          }
        }
      });
    };

    $scope.navigateOnTimeout = function(target){
      $timeout(function () {
        $scope.navigate(target);
      }, 300);
    };

    $scope.$on('$stateChangeStart',function() {
      try {
        var vuforiaCleanup = $injector.get('vuforiaCleanup');
        if (vuforiaCleanup) {
          vuforiaCleanup.requestCleanupAndPause();
        }
      } catch(e) {console.log(e);}
    });

    $scope.navigate = function(target){
      $state.go(target);
    };
  });

}(window, document, angular));

/**
 * Adds a description meta tag for each supported language.  If the meta tag already exists, it will update the contents.
 */
function appendDescriptionMetaData(descriptionObj) {
  descriptionObj = descriptionObj || {};
  var head = document.querySelector('head');

  // append a 'description' meta tag for each supported language
  Object.keys(descriptionObj).forEach(function(lang) {
    var meta = document.querySelector('meta[name="description"][lang="' + lang + '"]');
    if(!meta) {
      meta = document.createElement('meta');
      meta.name = "description";
      meta.lang = lang;
      meta.content = descriptionObj[lang];

      // add the meta tag to the document's head element
      head.appendChild(meta);
    } else {
      // update the meta tag value
      meta.content = descriptionObj[lang];
    }
  });
};

/**
 *  initialize the mobile app/experience title and populate the params in the window.twx.app.params object.
 */
function updateTitleWithExpTitle() {
  var defaultParams = {"vumark":{"id":"vumark","isbound":"false","isdeletable":"false","name":"ThingMark","value":""},"template":{"id":"template","isbound":"false","isdeletable":"false","name":"Thing Template","value":""},"thing":{"id":"thing","isbound":"false","isdeletable":"false","name":"Thing","value":""}};

  Object.keys(defaultParams).forEach(function(key) {
    if (defaultParams[key].value) {
      window.twx.app.params[key] = defaultParams[key].value;
    }
  });

  // get the index of the experience being loaded, default to the first view if the 'expIndex' is not passed on the URL

  var urlParams = new URLSearchParams(location.search);
  var title = '';
  var descriptionObj = {};
  if (urlParams.has('expIndex')) {
    //Old bookmarks will come through here, may not be correct if experiences have been redone in a different order
    var expIdx = parseInt(twx.app.fn.getParameterByName('expIndex', location.href) || '0', 10);
    title = experienceInfo.getTitleByIndex(expIdx);
    descriptionObj = experienceInfo.getDescription(expIdx);
  }
  else if (urlParams.has('expId')) {
    //expId could still be old/stale if experiences have been all deleted and redone
    var exp = experienceInfo.findExperienceById(parseFloat(urlParams.get('expId')));
    title = experienceInfo.getTitle(exp);
    descriptionObj = exp.description;
  }
  else {
    title = experienceInfo.getTitleByIndex(0);
    descriptionObj = experienceInfo.getDescription(0);
    if (!title) {
      title = urlParams.get('project');
    }
  }

  // set the page title as the name of the loaded experience
  document.title = title;

  appendDescriptionMetaData(descriptionObj);
}

var experienceInfo = new twx.app.ExperienceInfo({"name":"","version":"1.0.0","requires":["w320dp"],"experiences":[{"vumark":"40109:1","experienceType":"vumark","id":1,"index-keys":["urn:vuforia:vumark:40109:1"],"title":{"en":"Gemini Cabinet Walkthrough"},"description":{"en":"","en-US":""},"requires":["AR-tracking"],"tags":[],"icon":"","viewName":"Home","url-template":"index.html?expId=1&vumark={{vuforia:vumark}}","entryPoint":"index.html?expId=1","thumbnail":""}],"accessType":"public","designedfor":[]});
