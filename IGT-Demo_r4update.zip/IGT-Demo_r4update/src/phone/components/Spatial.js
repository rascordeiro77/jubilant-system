// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available
$scope.onload = function() {
 $scope.view.wdg['ffs'].shader = 'onesided';
  $scope.view.wdg['ffs'].texture = 'app/resources/Uploaded/GameTouch28_diffuse.png';
  $scope.view.wdg['model-2'].visible=false;
  $scope.$applyAsync();
}

$timeout(function() {

  //internals
  $scope.view.wdg['MgrMenuDisplay_Int'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 1;g f 1;b f 0";
  $scope.view.wdg['Printer_Int'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 1;g f 1;b f 0";
  $scope.view.wdg['innerDoor_Int'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 1;g f 1;b f 0";
  $scope.view.wdg['powerButton_Int'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 1;g f 1;b f 0";
  $scope.view.wdg['barCodeScanner_Int'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 1;g f 1;b f 0";
  $scope.view.wdg['billScanner_Int'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 1;g f 1;b f 0";
  $scope.view.wdg['playslipReader_Int'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 1;g f 1;b f 0";
  $scope.view.wdg['burster_Int'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 1;g f 1;b f 0";
  //externals
  $scope.view.wdg['doorlockExt'].shader  =  "pinger;rings f 3;rate f 5;direction f -1;r f 1;g f 0;b f 1";
  $scope.view.wdg['cashlessDevice'].shader  =  "pinger;rings f 3;rate f 5;direction f -1;r f 0;g f 1;b f 0";
  $scope.view.wdg['multimediaDisplay'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 0;g f 1;b f 0";
  $scope.view.wdg['QuickPickButtons'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 0;g f 1;b f 0";
  $scope.view.wdg['DispenseButton'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 0;g f 1;b f 0";
  $scope.view.wdg['TicketRetrieval'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 0;g f 1;b f 0";
  $scope.view.wdg['BarCodeReader'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 0;g f 1;b f 0";
  $scope.view.wdg['BillAcceptor'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 0;g f 1;b f 0";
  $scope.view.wdg['PrinterExt'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 0;g f 1;b f 0";
  $scope.view.wdg['payslip'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 0;g f 1;b f 0";
  $scope.view.wdg['info_options'].shader  = "pinger;rings f 5;rate f 10;direction f -1;r f 0;g f 1;b f 0";
}
         ,1000)
$scope.showModelOpen = function()
{
   /*$scope.view.wdg.ffs.shader = '';
  $scope.view.wdg.ffs.texture = '';
  $scope.$applyAsync();*/
  $scope.view.wdg['ffs'].visible=false;
  $scope.view.wdg['model-2'].visible=true;
  $scope.view.wdg['model-2']['sequence']="l-Creo 3D - door_5Fopen.pvi";
  $timeout(function() {
   		$scope.$broadcast('app.view["model-2"].svc.play')
 	}, 100)
 
  $scope.view.wdg["frontImage"]["visible"] = false
  
  $scope.view.wdg["cleanPS"]["visible"] = false
  $scope.view.wdg["clearJam"]["visible"] = false
  $scope.view.wdg["changePaper"]["visible"] = false
  $scope.view.wdg["jamBillAcceptor"]["visible"] = false
  $scope.view.wdg["removeMoneyfromBox"]["visible"] = false
  $scope.view.wdg["burster"]["visible"] = false
  $scope.view.wdg["doorLockImage"]["visible"] = false
  $scope.view.wdg['MgrMenuDisplay_Int']["visible"] = true
  $scope.view.wdg['Printer_Int']["visible"] = true
  $scope.view.wdg['innerDoor_Int']["visible"] = true
  $scope.view.wdg['powerButton_Int']["visible"] = true
  $scope.view.wdg['barCodeScanner_Int']["visible"] = true
  $scope.view.wdg['billScanner_Int']["visible"] = true
  $scope.view.wdg['doorlockExt']["visible"] = false
  $scope.view.wdg['playslipReader_Int']["visible"] = true
  $scope.view.wdg["loadTicket"]["visible"] = false
  $scope.view.wdg["burster_Int"]["visible"] = true
  $scope.view.wdg["burstersImage"]["visible"] = false
  //externals  
  $scope.view.wdg['cashlessDevice']["visible"] = false
  $scope.view.wdg['multimediaDisplay']["visible"] = false
  $scope.view.wdg['QuickPickButtons']["visible"] = false
  $scope.view.wdg['DispenseButton']["visible"] = false
  $scope.view.wdg['TicketRetrieval']["visible"] = false
  $scope.view.wdg['BarCodeReader']["visible"] = false
  $scope.view.wdg['BillAcceptor']["visible"] = false
  $scope.view.wdg['payslip']["visible"] = false
  $scope.view.wdg['PrinterExt']["visible"] = false
  $scope.view.wdg['cashlessImage']["visible"] = false
  $scope.view.wdg['multimediaImage']["visible"] = false
  $scope.view.wdg['quickPickImage']["visible"] = false
  $scope.view.wdg['scratchTicketImage']["visible"] = false
  $scope.view.wdg['ticketRetrievalImage']["visible"] = false
  $scope.view.wdg['barcodeReaderImage']["visible"] = false
  $scope.view.wdg['billacceptorImage']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['ticketsImage_Ext']["visible"] = false
  
    $scope.view.wdg['info_options']["visible"] = false
    $scope.view.wdg['info_optionsImage']["visible"] =  false
  $scope.view.wdg['closeDoor']["visible"] =  true
}
$scope.powerButton= function()
{
  $scope.view.wdg["cleanPS"]["visible"] = false
  $scope.view.wdg["burster"]["visible"] = false
  $scope.view.wdg["clearJam"]["visible"] = false
  $scope.view.wdg["changePaper"]["visible"] = false
  $scope.view.wdg["jamBillAcceptor"]["visible"] = false
  $scope.view.wdg["removeMoneyfromBox"]["visible"] = false
  $scope.view.wdg["loadTicket"]["visible"] = false
  $scope.view.wdg["powerButtonImage"]["visible"] = true
  $scope.view.wdg["doorLockImage"]["visible"] = false
  $scope.view.wdg['MgrMenuDisplayImage']["visible"] = false
  $scope.view.wdg['barCodeScannerImage']["visible"] = false
  $scope.view.wdg['BillAcceptorImage_Int']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['printerImage_Int']["visible"] = false
  $scope.view.wdg['innerDoorImage']["visible"] = false
  $scope.view.wdg["burstersImage"]["visible"] = false
}
$scope.menuDisplay= function()
{
  $scope.view.wdg["cleanPS"]["visible"] = false
  $scope.view.wdg["burster"]["visible"] = false
  $scope.view.wdg["clearJam"]["visible"] = false
  $scope.view.wdg["changePaper"]["visible"] = false
  $scope.view.wdg["jamBillAcceptor"]["visible"] = false
  $scope.view.wdg["removeMoneyfromBox"]["visible"] = false
  $scope.view.wdg["loadTicket"]["visible"] = false
  $scope.view.wdg["MgrMenuDisplayImage"]["visible"] = true
  $scope.view.wdg["powerButtonImage"]["visible"] = false
  $scope.view.wdg["doorLockImage"]["visible"] = false
  $scope.view.wdg['barCodeScannerImage']["visible"] = false
  $scope.view.wdg['BillAcceptorImage_Int']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['printerImage_Int']["visible"] = false
  $scope.view.wdg['innerDoorImage']["visible"] = false
  $scope.view.wdg["burstersImage"]["visible"] = false
}
$scope.barcodeScanner= function()
{
  $scope.view.wdg["cleanPS"]["visible"] = false
  $scope.view.wdg["clearJam"]["visible"] = false
  $scope.view.wdg["burster"]["visible"] = false
  $scope.view.wdg["changePaper"]["visible"] = false
  $scope.view.wdg["jamBillAcceptor"]["visible"] = false
  $scope.view.wdg["removeMoneyfromBox"]["visible"] = false
  $scope.view.wdg["loadTicket"]["visible"] = false
  $scope.view.wdg["barCodeScannerImage"]["visible"] = true
  $scope.view.wdg["powerButtonImage"]["visible"] = false
  $scope.view.wdg["doorLockImage"]["visible"] = false
  $scope.view.wdg['MgrMenuDisplayImage']["visible"] = false
  $scope.view.wdg['BillAcceptorImage_Int']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['printerImage_Int']["visible"] = false
  $scope.view.wdg['innerDoorImage']["visible"] = false
  $scope.view.wdg["burstersImage"]["visible"] = false
}
$scope.billScanner= function()
{
  $scope.view.wdg["cleanPS"]["visible"] = false
  $scope.view.wdg["clearJam"]["visible"] = false
  $scope.view.wdg["burster"]["visible"] = false
  $scope.view.wdg["changePaper"]["visible"] = false
  $scope.view.wdg["jamBillAcceptor"]["visible"] = true
  $scope.view.wdg["removeMoneyfromBox"]["visible"] = true
  $scope.view.wdg["loadTicket"]["visible"] = false
  $scope.view.wdg["BillAcceptorImage_Int"]["visible"] = true
  $scope.view.wdg["powerButtonImage"]["visible"] = false
  $scope.view.wdg["doorLockImage"]["visible"] = false
  $scope.view.wdg['MgrMenuDisplayImage']["visible"] = false
  $scope.view.wdg['barCodeScannerImage']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['printerImage_Int']["visible"] = false
  $scope.view.wdg['innerDoorImage']["visible"] = false
  $scope.view.wdg["burstersImage"]["visible"] = false
}
$scope.payslip= function()
{
  $scope.view.wdg["payslipReaderImage"]["visible"] = true
  $scope.view.wdg["cleanPS"]["visible"] = true
  $scope.view.wdg["clearJam"]["visible"] = false
  $scope.view.wdg["changePaper"]["visible"] = false
  $scope.view.wdg["burster"]["visible"] = false
  $scope.view.wdg["jamBillAcceptor"]["visible"] = false
  $scope.view.wdg["loadTicket"]["visible"] = false
  $scope.view.wdg["removeMoneyfromBox"]["visible"] = false
  $scope.view.wdg["powerButtonImage"]["visible"] = false
  $scope.view.wdg["doorLockImage"]["visible"] = false
  $scope.view.wdg['MgrMenuDisplayImage']["visible"] = false
  $scope.view.wdg['barCodeScannerImage']["visible"] = false
  $scope.view.wdg['BillAcceptorImage_Int']["visible"] = false
  $scope.view.wdg['printerImage_Int']["visible"] = false
  $scope.view.wdg['innerDoorImage']["visible"] = false
  $scope.view.wdg["burstersImage"]["visible"] = false
}
$scope.printer= function()
{
  $scope.view.wdg["printerImage_Int"]["visible"] = true
  $scope.view.wdg["clearJam"]["visible"] = true
  $scope.view.wdg["burster"]["visible"] = false
  $scope.view.wdg["changePaper"]["visible"] = true
  $scope.view.wdg["cleanPS"]["visible"] = false
  $scope.view.wdg["jamBillAcceptor"]["visible"] = false
  $scope.view.wdg["removeMoneyfromBox"]["visible"] = false
  $scope.view.wdg["loadTicket"]["visible"] = false
  $scope.view.wdg["powerButtonImage"]["visible"] = false
  $scope.view.wdg["doorLockImage"]["visible"] = false
  $scope.view.wdg['MgrMenuDisplayImage']["visible"] = false
  $scope.view.wdg['barCodeScannerImage']["visible"] = false
  $scope.view.wdg['BillAcceptorImage_Int']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['innerDoorImage']["visible"] = false
  $scope.view.wdg["burstersImage"]["visible"] = false
}
$scope.innerdoor= function()
{
  $scope.view.wdg["clearJam"]["visible"] = false
  $scope.view.wdg["burster"]["visible"] = false
  $scope.view.wdg["changePaper"]["visible"] = false
  $scope.view.wdg["cleanPS"]["visible"] = false
  $scope.view.wdg["jamBillAcceptor"]["visible"] = false
  $scope.view.wdg["removeMoneyfromBox"]["visible"] = false
  $scope.view.wdg["loadTicket"]["visible"] = false
  $scope.view.wdg["innerDoorImage"]["visible"] = true
  $scope.view.wdg["powerButtonImage"]["visible"] = false
  $scope.view.wdg["doorLockImage"]["visible"] = false
  $scope.view.wdg['MgrMenuDisplayImage']["visible"] = false
  $scope.view.wdg['barCodeScannerImage']["visible"] = false
  $scope.view.wdg['BillAcceptorImage_Int']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['printerImage_Int']["visible"] = false
  $scope.view.wdg["burstersImage"]["visible"] = false
}
$scope.showBurster= function(){
  $scope.view.wdg["clearJam"]["visible"] = false
  $scope.view.wdg["burster"]["visible"] = true
  $scope.view.wdg["loadTicket"]["visible"] = true
  $scope.view.wdg["changePaper"]["visible"] = false
  $scope.view.wdg["cleanPS"]["visible"] = false
  $scope.view.wdg["jamBillAcceptor"]["visible"] = false
  $scope.view.wdg["removeMoneyfromBox"]["visible"] = false
  $scope.view.wdg["burstersImage"]["visible"] = true
  $scope.view.wdg["innerDoorImage"]["visible"] = false
  $scope.view.wdg["powerButtonImage"]["visible"] = false
  $scope.view.wdg["doorLockImage"]["visible"] = false
  $scope.view.wdg['MgrMenuDisplayImage']["visible"] = false
  $scope.view.wdg['barCodeScannerImage']["visible"] = false
  $scope.view.wdg['BillAcceptorImage_Int']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['printerImage_Int']["visible"] = false
}
//external gamer
$scope.cashlessdevice = function(){
  $scope.view.wdg['doorLockImage']["visible"] = false
  $scope.view.wdg['cashlessImage']["visible"] = true
  $scope.view.wdg['multimediaImage']["visible"] = false
  $scope.view.wdg['quickPickImage']["visible"] = false
  $scope.view.wdg['scratchTicketImage']["visible"] = false
  $scope.view.wdg['ticketRetrievalImage']["visible"] = false
  $scope.view.wdg['barcodeReaderImage']["visible"] = false
  $scope.view.wdg['billacceptorImage']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['printerExtImage']["visible"] = false
  $scope.view.wdg['info_optionsImage']["visible"] = false
}
$scope.multimediadisplay = function(){
  $scope.view.wdg['doorLockImage']["visible"] = false
  $scope.view.wdg['cashlessImage']["visible"] = false
  $scope.view.wdg['multimediaImage']["visible"] = true
  $scope.view.wdg['quickPickImage']["visible"] = false
  $scope.view.wdg['scratchTicketImage']["visible"] = false
  $scope.view.wdg['ticketRetrievalImage']["visible"] = false
  $scope.view.wdg['barcodeReaderImage']["visible"] = false
  $scope.view.wdg['billacceptorImage']["visible"] = false
  $scope.view.wdg['info_optionsImage']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['printerExtImage']["visible"] = false
}
$scope.quickpick = function(){
  $scope.view.wdg['doorLockImage']["visible"] = false
  $scope.view.wdg['cashlessImage']["visible"] = false
  $scope.view.wdg['multimediaImage']["visible"] = false
  $scope.view.wdg['quickPickImage']["visible"] = true
  $scope.view.wdg['scratchTicketImage']["visible"] = false
  $scope.view.wdg['ticketRetrievalImage']["visible"] = false
  $scope.view.wdg['barcodeReaderImage']["visible"] = false
  $scope.view.wdg['billacceptorImage']["visible"] = false
  $scope.view.wdg['info_optionsImage']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['printerExtImage']["visible"] = false
}
$scope.dispense = function(){
  $scope.view.wdg['doorLockImage']["visible"] = false
  $scope.view.wdg['cashlessImage']["visible"] = false
  $scope.view.wdg['multimediaImage']["visible"] = false
  $scope.view.wdg['quickPickImage']["visible"] = false
  $scope.view.wdg['scratchTicketImage']["visible"] = true
  $scope.view.wdg['ticketRetrievalImage']["visible"] = false
  $scope.view.wdg['barcodeReaderImage']["visible"] = false
  $scope.view.wdg['billacceptorImage']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['info_optionsImage']["visible"] = false
  $scope.view.wdg['printerExtImage']["visible"] = false
}
$scope.ticketretrieval = function(){
  $scope.view.wdg['doorLockImage']["visible"] = false
  $scope.view.wdg['cashlessImage']["visible"] = false
  $scope.view.wdg['multimediaImage']["visible"] = false
  $scope.view.wdg['quickPickImage']["visible"] = false
  $scope.view.wdg['scratchTicketImage']["visible"] = false
  $scope.view.wdg['ticketRetrievalImage']["visible"] = true
  $scope.view.wdg['barcodeReaderImage']["visible"] = false
  $scope.view.wdg['billacceptorImage']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['info_optionsImage']["visible"] = false
  $scope.view.wdg['printerExtImage']["visible"] = false
}
$scope.barcodereader = function(){
  $scope.view.wdg['doorLockImage']["visible"] = false
  $scope.view.wdg['cashlessImage']["visible"] = false
  $scope.view.wdg['multimediaImage']["visible"] = false
  $scope.view.wdg['quickPickImage']["visible"] = false
  $scope.view.wdg['scratchTicketImage']["visible"] = false
  $scope.view.wdg['ticketRetrievalImage']["visible"] = false
  $scope.view.wdg['barcodeReaderImage']["visible"] = true
  $scope.view.wdg['billacceptorImage']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['info_optionsImage']["visible"] = false
  $scope.view.wdg['printerExtImage']["visible"] = false
}
$scope.billacceptor = function(){
  $scope.view.wdg['doorLockImage']["visible"] = false
  $scope.view.wdg['cashlessImage']["visible"] = false
  $scope.view.wdg['multimediaImage']["visible"] = false
  $scope.view.wdg['quickPickImage']["visible"] = false
  $scope.view.wdg['scratchTicketImage']["visible"] = false
  $scope.view.wdg['ticketRetrievalImage']["visible"] = false
  $scope.view.wdg['barcodeReaderImage']["visible"] = false
  $scope.view.wdg['billacceptorImage']["visible"] = true
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['info_optionsImage']["visible"] = false
  $scope.view.wdg['printerExtImage']["visible"] = false}
$scope.playslip_Ext = function(){
  $scope.view.wdg['doorLockImage']["visible"] = false
  $scope.view.wdg['cashlessImage']["visible"] = false
  $scope.view.wdg['multimediaImage']["visible"] = false
  $scope.view.wdg['quickPickImage']["visible"] = false
  $scope.view.wdg['scratchTicketImage']["visible"] = false
  $scope.view.wdg['ticketRetrievalImage']["visible"] = false
  $scope.view.wdg['barcodeReaderImage']["visible"] = false
  $scope.view.wdg['billacceptorImage']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = true
  $scope.view.wdg['info_optionsImage']["visible"] = false
  $scope.view.wdg['printerExtImage']["visible"] = false
}
$scope.printerext = function(){
  $scope.view.wdg['doorLockImage']["visible"] = false
  $scope.view.wdg['cashlessImage']["visible"] = false
  $scope.view.wdg['multimediaImage']["visible"] = false
  $scope.view.wdg['quickPickImage']["visible"] = false
  $scope.view.wdg['scratchTicketImage']["visible"] = false
  $scope.view.wdg['ticketRetrievalImage']["visible"] = false
  $scope.view.wdg['barcodeReaderImage']["visible"] = false
  $scope.view.wdg['billacceptorImage']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['info_optionsImage']["visible"] = false
  $scope.view.wdg['printerExtImage']["visible"] = true
}
$scope.infooptions = function(){
  $scope.view.wdg['doorLockImage']["visible"] = false
  $scope.view.wdg['cashlessImage']["visible"] = false
  $scope.view.wdg['multimediaImage']["visible"] = false
  $scope.view.wdg['quickPickImage']["visible"] = false
  $scope.view.wdg['scratchTicketImage']["visible"] = false
  $scope.view.wdg['ticketRetrievalImage']["visible"] = false
  $scope.view.wdg['barcodeReaderImage']["visible"] = false
  $scope.view.wdg['billacceptorImage']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['printerExtImage']["visible"] = false
  $scope.view.wdg['info_optionsImage']["visible"] = true
}

$scope.doorClose = function() 
{
  
  /*$scope.view.wdg.ffs.shader = 'onesided';
  $scope.view.wdg.ffs.texture = 'app/resources/Uploaded/GameTouch28_diffuse.png';
  $scope.$applyAsync();*/
  $scope.view.wdg['ffs'].visible=true;
  $scope.view.wdg['model-2'].visible=false;
  $scope.view.wdg['model-2']['sequence']='';
   $scope.view.wdg["frontImage"]["visible"] = true;
    $scope.view.wdg["powerButtonImage"]["visible"] = false
  $scope.view.wdg["doorLockImage"]["visible"] = false
  $scope.view.wdg['MgrMenuDisplayImage']["visible"] = false
  $scope.view.wdg['barCodeScannerImage']["visible"] = false
  $scope.view.wdg['BillAcceptorImage_Int']["visible"] = false
  $scope.view.wdg['payslipReaderImage']["visible"] = false
  $scope.view.wdg['printerImage_Int']["visible"] = false
  $scope.view.wdg['innerDoorImage']["visible"] = false
  $scope.view.wdg["burstersImage"]["visible"] = false
   $scope.view.wdg["cleanPS"]["visible"] = false
  $scope.view.wdg["clearJam"]["visible"] = false
  $scope.view.wdg["changePaper"]["visible"] = false
  $scope.view.wdg["jamBillAcceptor"]["visible"] = false
  $scope.view.wdg["removeMoneyfromBox"]["visible"] = false
  $scope.view.wdg["burster"]["visible"] = false
  $scope.view.wdg["doorLockImage"]["visible"] = false
  $scope.view.wdg['MgrMenuDisplay_Int']["visible"] = false
  $scope.view.wdg['Printer_Int']["visible"] = false
  $scope.view.wdg['innerDoor_Int']["visible"] = false
  $scope.view.wdg['powerButton_Int']["visible"] = false
  $scope.view.wdg['barCodeScanner_Int']["visible"] = false
  $scope.view.wdg['billScanner_Int']["visible"] = false
  $scope.view.wdg['doorlockExt']["visible"] = true
  $scope.view.wdg['playslipReader_Int']["visible"] = false
  $scope.view.wdg["loadTicket"]["visible"] = false
  $scope.view.wdg["burster_Int"]["visible"] = false
  $scope.view.wdg["burstersImage"]["visible"] = false
  $scope.view.wdg['cashlessDevice']["visible"] = true
  $scope.view.wdg['multimediaDisplay']["visible"] = true
  $scope.view.wdg['QuickPickButtons']["visible"] = true
  $scope.view.wdg['DispenseButton']["visible"] = true
  $scope.view.wdg['TicketRetrieval']["visible"] = true
  $scope.view.wdg['BarCodeReader']["visible"] = true
  $scope.view.wdg['BillAcceptor']["visible"] = true
  $scope.view.wdg['payslip']["visible"] = true
  $scope.view.wdg['PrinterExt']["visible"] = true
  $scope.view.wdg['closeDoor']["visible"] = false
  $scope.view.wdg['ticketsImage_Ext']["visible"] = true
  
  
}
$scope.playVideo = function(video)
{
  $scope.setWidgetProp('video-1', 'videosrc', "app/resources/Uploaded/" + video)
  $timeout(function() {
    $scope.$broadcast('app.view["ARView"].wdg["video-1"].svc.play');
    $scope.$applyAsync()
  }
           , 500);
}
